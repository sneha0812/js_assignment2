function exponentAndBase(number1, number2) {
    let num1 = prompt("enter base number");
    let num2 = prompt("enter exponent");
    let calculation = Math.pow(num1, num2);
    console.log(calculation);
}
exponentAndBase();
