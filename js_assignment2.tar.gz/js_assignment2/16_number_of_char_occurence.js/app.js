function charOccurence() {
   let count = 0, i, ch;
   let array = new Array();
   let str = prompt("enter a string");
    for (i = 0; str[i] != '\0'; i++) {
      if (str[i] == ch)
         count++;
   }

   if (count == 0)
      console.log(count);
   else
     console.log(count);
}

charOccurence();
