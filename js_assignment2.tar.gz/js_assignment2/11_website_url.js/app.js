function websiteurl(string){
  console.log(document.URL);
}
websiteurl();
