function currentWindow(print){
  return window.print();
}
currentWindow();
